from student_utils import add, to_upper
from student_utils.helpers import prefix_message

print(add(5, 10))
print(to_upper("hello"))
print(prefix_message("Task completed"))
