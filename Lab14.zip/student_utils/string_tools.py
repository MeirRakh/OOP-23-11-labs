def to_upper(text):
    return text.upper()

def count_words(text):
    return len(text.split())
