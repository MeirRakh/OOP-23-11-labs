def prefix_message(message, prefix="INFO"):
    return f"[{prefix}] {message}"
